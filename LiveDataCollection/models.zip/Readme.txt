Information about this package.
===============================
Exported 2025-01-23 16:30 UTC

Name            BatchSize   Epochs    LayerCount   LearningRate         WeightDecay          SplitCount Patience 
conv1d-medium-balanced-0 4           100       16           0.004                0.0001               2         20       
conv1d-medium-balanced-1 4           100       16           0.004                0.0001               2         20       
conv1d-medium-balanced-2 4           100       16           0.004                0.0001               2         20       
conv1d-medium-balanced-3 4           100       16           0.004                0.0001               2         20       
